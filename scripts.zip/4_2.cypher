//4.2
MATCH (p:Person)-[:HAS_NAME]->(n:Name)
WITH count(DISTINCT p) AS p_cnt, n
ORDER BY p_cnt DESC
LIMIT 5
WITH collect(n) AS top_names
MATCH (p:Person)-[:HAS_NAME]->(n:Name)
WHERE n IN top_names
RETURN p, n