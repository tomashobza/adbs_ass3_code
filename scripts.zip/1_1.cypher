//1.1
MATCH (l:Language)<-[:SPEAKS_LANGUAGE]-(p:Person)-[:RECEIVED_AWARD]->(a:Award) RETURN DISTINCT l.name;