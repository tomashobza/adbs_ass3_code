//3
MATCH
    (p1:Person)-[:BORN_IN]->(p:Place)<-[:BORN_IN]-(p2:Person),
    (p1:Person)-[:STUDIED_AT]->(u:University)<-[:STUDIED_AT]-(p2:Person),
    (p1:Person)-[:RECEIVED_AWARD]->(a1:Award),
    (p2:Person)-[:RECEIVED_AWARD]->(a2:Award)
WHERE p1 <> p2
RETURN p1, p2, u, p, a1, a2 LIMIT 1;