//2.2
MATCH (p:Person)-[:BORN_IN]->()-[:LOCATED_IN]->(r:Region) RETURN r.name, COUNT(DISTINCT p) as p_count ORDER BY p_count DESC LIMIT 10;