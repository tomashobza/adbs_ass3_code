//5.1
MATCH
(p1:Person)-[:STUDIED_AT]->(u:University),
(p1:Person)-[:STUDIED_AT]->(v:University),
(p2:Person)-[:EMPLOYED_AT]->(u:University),
(p2:Person)-[:EMPLOYED_AT]->(v:University)
WHERE v <> u AND p1 <> p2
MERGE (u)-[:CONNECTED]-(v)