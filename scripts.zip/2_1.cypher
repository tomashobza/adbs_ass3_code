//2.1
MATCH (u:University)<-[:EMPLOYED_AT]-(p) RETURN u.name, COUNT(p) as p_count ORDER BY p_count DESC LIMIT 10;