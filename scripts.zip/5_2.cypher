//5.2
MATCH 
    (a:University {name: "TU Wien"}),
    (b:University)-[:LOCATED_IN]->(:Country {name: "Germany"})
MATCH path = shortestPath((a)-[:CONNECTED*]-(b))
RETURN path