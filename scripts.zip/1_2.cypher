//1.2
MATCH (c:Country)<-[:LOCATED_IN]-(u:University)<-[:STUDIED_AT]-(p:Person) RETURN DISTINCT c;