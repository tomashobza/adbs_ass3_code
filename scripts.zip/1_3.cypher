//1.3
MATCH (c:Country)<-[:LOCATED_IN]-(u:University)<-[:STUDIED_AT]-(p:Person) RETURN DISTINCT c, COUNT(DISTINCT p) as people_count;