//4.1
MATCH (p:Person)-[:RECEIVED_AWARD]->(:Award)
WITH DISTINCT p
WHERE p.last_name IS NOT NULL
MERGE (n:Name {name: p.last_name})
MERGE (p)-[:HAS_NAME]->(n);
// 2. Dates of birth
MATCH (p:Person)-[:RECEIVED_AWARD]->(:Award)
WITH DISTINCT p
WHERE p.date_of_birth IS NOT NULL
MERGE (dob:DateOfBirth {date_of_birth: p.date_of_birth})
MERGE (p)-[:HAS_DOB]->(dob);